# Prompt pack

Paste-ready prompts for www.shmoozeatl.com. Use the variant that matches your tool.

## v0.txt

```
Build a landing page with this exact visual language.
COLORS:
  #000000
  #333333
  #ffffff
  #e1ded4
  #bbbbbb
  #0099dd
  #efece6
  #a9a9a9
  #0d121c
  #cdd5df
FONTS: [object Object], [object Object], [object Object]
SPACING: 1, 4, 19, 22, 25, 30, 32, 38
RADIUS: 2, 12, 26, 50, 300
SHADOWS: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px
MATERIAL LANGUAGE: flat
VOICE: Tone: friendly · Headings: Title Case · CTA verbs: [object Object], [object Object], [object Object], [object Object], [object Object], [object Object]
SECTIONS (in order):
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing — heading: "Businesses You Can Trust"
- testimonials
- footer
Use Tailwind. Match these tokens exactly. Keep the material language consistent.
```

## lovable.txt

```
Clone the design language of this landing page and build a fresh equivalent.
Visual feel: flat. Tone: friendly · Headings: Title Case · CTA verbs: [object Object], [object Object], [object Object], [object Object], [object Object], [object Object]
Primary palette: #000000, #333333, #ffffff, #e1ded4, #bbbbbb.
Typography: [object Object], [object Object], [object Object].
Corner radius vocabulary: 2, 12, 26, 50, 300.
Shadow vocabulary: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px.
Page structure:
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing — heading: "Businesses You Can Trust"
- testimonials
- footer
```

## cursor.md

```
# Design brief
Page type: **landing**.
Material language: **flat**.
Voice: Tone: friendly · Headings: Title Case · CTA verbs: [object Object], [object Object], [object Object], [object Object], [object Object], [object Object].
## Tokens
```ts
export const tokens = {
  colors: ['#000000', '#333333', '#ffffff', '#e1ded4', '#bbbbbb', '#0099dd', '#efece6', '#a9a9a9', '#0d121c', '#cdd5df'],
  fonts: ['[object Object]', '[object Object]', '[object Object]'],
  radii: ['2', '12', '26', '50', '300'],
  shadows: ['rgba(0, 0, 0, 0) 0px 0px 0px 1px', 'rgb(0, 0, 0) 0px 0px 0px 0px', 'rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px'],
};
```
## Sections
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing — heading: "Businesses You Can Trust"
- testimonials
- footer
```

## claude-artifacts.md

```
Create a React artifact that reproduces this brand's design language.
Page intent: landing.
Material language: flat.
Voice: Tone: friendly · Headings: Title Case · CTA verbs: [object Object], [object Object], [object Object], [object Object], [object Object], [object Object].
Colors to use: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd, #efece6, #a9a9a9, #0d121c, #cdd5df.
Fonts: [object Object], [object Object], [object Object].
Radius vocabulary: 2, 12, 26, 50, 300.
Sections:
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing — heading: "Businesses You Can Trust"
- testimonials
- footer
Use Tailwind via CDN, lucide-react for icons, and keep the material language consistent across sections. Do not add extra decorative elements outside this vocabulary.
```

## Recipes

### button

# Recipe: button
Build one button component that matches this brand.
Palette: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd
Typography: [object Object], [object Object], [object Object]
Material: flat
Signals: Radius: 2, 12, 26, 50, 300 · Shadows: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px
## Anatomy (detected)
```json
{
  "kind": "button",
  "structuralHash": "body>div>script>svg>div>script",
  "instanceCount": 1,
  "variants": [
    {
      "css": {
        "background": "rgb(225, 222, 212)",
        "color": "rgb(0, 0, 0)",
        "padding": "0px 0px 0px 0px",
        "borderRadius": "0px",
        "border": "0px none rgb(0, 0, 0)",
        "fontSize": "16px",
        "fontWeight": "400"
      },
      "instanceCount": 1
    }
  ]
}
```


### button

# Recipe: button
Build one button component that matches this brand.
Palette: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd
Typography: [object Object], [object Object], [object Object]
Material: flat
Signals: Radius: 2, 12, 26, 50, 300 · Shadows: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px
## Anatomy (detected)
```json
{
  "kind": "button",
  "structuralHash": "a",
  "instanceCount": 6,
  "variants": [
    {
      "css": {
        "background": "rgb(0, 0, 0)",
        "color": "rgb(255, 255, 255)",
        "padding": "32px 48px 32px 48px",
        "borderRadius": "300px",
        "border": "3px solid rgb(0, 0, 0)",
        "fontSize": "16px",
        "fontWeight": "400"
      },
      "instanceCount": 4
    },
    {
      "css": {
        "background": "rgba(0, 0, 0, 0.12)",
        "color": "rgb(255, 255, 255)",
        "padding": "10px 10px 10px 10px",
        "borderRadius": "0px",
        "border": "0px none rgb(255, 255, 255)",
        "fontSize": "14px",
        "fontWeight": "400"
      },
      "instanceCount": 2
    }
  ]
}
```


### button

# Recipe: button
Build one button component that matches this brand.
Palette: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd
Typography: [object Object], [object Object], [object Object]
Material: flat
Signals: Radius: 2, 12, 26, 50, 300 · Shadows: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px
## Anatomy (detected)
```json
{
  "kind": "button",
  "structuralHash": "button>span>span",
  "instanceCount": 4,
  "variants": [
    {
      "css": {
        "background": "rgba(0, 0, 0, 0)",
        "color": "rgb(0, 0, 0)",
        "padding": "1.6px 0px 1.6px 0px",
        "borderRadius": "0px",
        "border": "0px none rgb(0, 0, 0)",
        "fontSize": "16px",
        "fontWeight": "400"
      },
      "instanceCount": 3
    },
    {
      "css": {
        "background": "rgba(0, 0, 0, 0)",
        "color": "rgb(0, 0, 0)",
        "padding": "32px 48px 32px 48px",
        "borderRadius": "300px",
        "border": "3px solid rgb(0, 0, 0)",
        "fontSize": "16px",
        "fontWeight": "400"
      },
      "instanceCount": 1
    }
  ]
}
```


### button

# Recipe: button
Build one button component that matches this brand.
Palette: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd
Typography: [object Object], [object Object], [object Object]
Material: flat
Signals: Radius: 2, 12, 26, 50, 300 · Shadows: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px
## Anatomy (detected)
```json
{
  "kind": "button",
  "structuralHash": "div>div",
  "instanceCount": 1,
  "variants": [
    {
      "css": {
        "background": "rgba(0, 0, 0, 0)",
        "color": "rgb(0, 0, 0)",
        "padding": "0px 0px 0px 0px",
        "borderRadius": "0px",
        "border": "0px none rgb(0, 0, 0)",
        "fontSize": "16px",
        "fontWeight": "400"
      },
      "instanceCount": 1
    }
  ]
}
```


### button

# Recipe: button
Build one button component that matches this brand.
Palette: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd
Typography: [object Object], [object Object], [object Object]
Material: flat
Signals: Radius: 2, 12, 26, 50, 300 · Shadows: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px
## Anatomy (detected)
```json
{
  "kind": "button",
  "structuralHash": "div>a",
  "instanceCount": 1,
  "variants": [
    {
      "css": {
        "background": "rgba(0, 0, 0, 0)",
        "color": "rgb(0, 0, 0)",
        "padding": "0px 0px 0px 0px",
        "borderRadius": "0px",
        "border": "0px none rgb(0, 0, 0)",
        "fontSize": "16px",
        "fontWeight": "400"
      },
      "instanceCount": 1
    }
  ]
}
```


### input

# Recipe: input
Build one input component that matches this brand.
Palette: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd
Typography: [object Object], [object Object], [object Object]
Material: flat
Signals: Radius: 2, 12, 26, 50, 300 · Shadows: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px
## Anatomy (detected)
```json
{
  "kind": "input",
  "structuralHash": "input",
  "instanceCount": 7,
  "variants": [
    {
      "css": {
        "background": "rgba(0, 0, 0, 0)",
        "color": "rgb(0, 0, 0)",
        "padding": "10px 20px 10px 20px",
        "borderRadius": "25.84px",
        "border": "2px solid rgba(0, 0, 0, 0)",
        "fontSize": "16px",
        "fontWeight": "400"
      },
      "instanceCount": 5
    },
    {
      "css": {
        "background": "rgb(250, 250, 250)",
        "color": "rgb(0, 0, 0)",
        "padding": "10px 10px 10px 10px",
        "borderRadius": "25.84px",
        "border": "1px solid rgb(169, 169, 169)",
        "fontSize": "16px",
        "fontWeight": "400"
      },
      "instanceCount": 2
    }
  ]
}
```


### input

# Recipe: input
Build one input component that matches this brand.
Palette: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd
Typography: [object Object], [object Object], [object Object]
Material: flat
Signals: Radius: 2, 12, 26, 50, 300 · Shadows: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px
## Anatomy (detected)
```json
{
  "kind": "input",
  "structuralHash": "textarea",
  "instanceCount": 1,
  "variants": [
    {
      "css": {
        "background": "rgba(0, 0, 0, 0)",
        "color": "rgb(0, 0, 0)",
        "padding": "10px 20px 10px 20px",
        "borderRadius": "25.84px",
        "border": "2px solid rgba(0, 0, 0, 0)",
        "fontSize": "16px",
        "fontWeight": "400"
      },
      "instanceCount": 1
    }
  ]
}
```


### button

# Recipe: button
Build one button component that matches this brand.
Palette: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd
Typography: [object Object], [object Object], [object Object]
Material: flat
Signals: Radius: 2, 12, 26, 50, 300 · Shadows: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px
## Anatomy (detected)
```json
{
  "kind": "button",
  "structuralHash": "div>button",
  "instanceCount": 1,
  "variants": [
    {
      "css": {
        "background": "rgba(0, 0, 0, 0)",
        "color": "rgb(0, 0, 0)",
        "padding": "0px 0px 0px 0px",
        "borderRadius": "0px",
        "border": "0px none rgb(0, 0, 0)",
        "fontSize": "16px",
        "fontWeight": "400"
      },
      "instanceCount": 1
    }
  ]
}
```


### button

# Recipe: button
Build one button component that matches this brand.
Palette: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd
Typography: [object Object], [object Object], [object Object]
Material: flat
Signals: Radius: 2, 12, 26, 50, 300 · Shadows: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px
## Anatomy (detected)
```json
{
  "kind": "button",
  "structuralHash": "span>span>span>span",
  "instanceCount": 1,
  "variants": [
    {
      "css": {
        "background": "rgba(0, 0, 0, 0)",
        "color": "rgb(0, 0, 0)",
        "padding": "0px 0px 0px 0px",
        "borderRadius": "0px",
        "border": "0px none rgb(0, 0, 0)",
        "fontSize": "16px",
        "fontWeight": "400"
      },
      "instanceCount": 1
    }
  ]
}
```


### button

# Recipe: button
Build one button component that matches this brand.
Palette: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd
Typography: [object Object], [object Object], [object Object]
Material: flat
Signals: Radius: 2, 12, 26, 50, 300 · Shadows: rgba(0, 0, 0, 0) 0px 0px 0px 1px | rgb(0, 0, 0) 0px 0px 0px 0px | rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px
## Anatomy (detected)
```json
{
  "kind": "button",
  "structuralHash": "button",
  "instanceCount": 2,
  "variants": [
    {
      "css": {
        "background": "rgb(0, 153, 221)",
        "color": "rgb(255, 255, 255)",
        "padding": "8.5px 22.5px 8.5px 22.5px",
        "borderRadius": "0px",
        "border": "0px none rgb(255, 255, 255)",
        "fontSize": "15px",
        "fontWeight": "700"
      },
      "instanceCount": 2
    }
  ]
}
```

