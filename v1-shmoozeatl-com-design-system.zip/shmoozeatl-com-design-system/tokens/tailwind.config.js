/** @type {import('tailwindcss').Config} */
export default {
  theme: {
    extend: {
    colors: {
        primary: {
            '50': 'hsl(198, 100%, 97%)',
            '100': 'hsl(198, 100%, 94%)',
            '200': 'hsl(198, 100%, 86%)',
            '300': 'hsl(198, 100%, 76%)',
            '400': 'hsl(198, 100%, 64%)',
            '500': 'hsl(198, 100%, 50%)',
            '600': 'hsl(198, 100%, 40%)',
            '700': 'hsl(198, 100%, 32%)',
            '800': 'hsl(198, 100%, 24%)',
            '900': 'hsl(198, 100%, 16%)',
            '950': 'hsl(198, 100%, 10%)',
            DEFAULT: '#0099dd'
        },
        secondary: {
            '50': 'hsl(46, 18%, 97%)',
            '100': 'hsl(46, 18%, 94%)',
            '200': 'hsl(46, 18%, 86%)',
            '300': 'hsl(46, 18%, 76%)',
            '400': 'hsl(46, 18%, 64%)',
            '500': 'hsl(46, 18%, 50%)',
            '600': 'hsl(46, 18%, 40%)',
            '700': 'hsl(46, 18%, 32%)',
            '800': 'hsl(46, 18%, 24%)',
            '900': 'hsl(46, 18%, 16%)',
            '950': 'hsl(46, 18%, 10%)',
            DEFAULT: '#e1ded4'
        },
        accent: {
            '50': 'hsl(220, 37%, 97%)',
            '100': 'hsl(220, 37%, 94%)',
            '200': 'hsl(220, 37%, 86%)',
            '300': 'hsl(220, 37%, 76%)',
            '400': 'hsl(220, 37%, 64%)',
            '500': 'hsl(220, 37%, 50%)',
            '600': 'hsl(220, 37%, 40%)',
            '700': 'hsl(220, 37%, 32%)',
            '800': 'hsl(220, 37%, 24%)',
            '900': 'hsl(220, 37%, 16%)',
            '950': 'hsl(220, 37%, 10%)',
            DEFAULT: '#0d121c'
        },
        'neutral-50': '#000000',
        'neutral-100': '#333333',
        'neutral-200': '#ffffff',
        'neutral-300': '#bbbbbb',
        'neutral-400': '#efece6',
        'neutral-500': '#a9a9a9',
        'neutral-600': '#cdd5df',
        background: '#e1ded4',
        foreground: '#000000'
    },
    fontFamily: {
        body: [
            'SFico',
            'sans-serif'
        ],
        heading: [
            'Shrikhand',
            'sans-serif'
        ]
    },
    fontSize: {
        '14': [
            '14px',
            {
                lineHeight: '21px'
            }
        ],
        '15': [
            '15px',
            {
                lineHeight: '19.5px'
            }
        ],
        '16': [
            '16px',
            {
                lineHeight: 'normal'
            }
        ],
        '48': [
            '48px',
            {
                lineHeight: '48px'
            }
        ],
        '56': [
            '56px',
            {
                lineHeight: '24px'
            }
        ],
        '62.08': [
            '62.08px',
            {
                lineHeight: '65.5565px',
                letterSpacing: '-1.2416px'
            }
        ],
        '54.4': [
            '54.4px',
            {
                lineHeight: '76.16px',
                letterSpacing: '-1.088px'
            }
        ],
        '43.648': [
            '43.648px',
            {
                lineHeight: '48.6064px',
                letterSpacing: '-0.87296px'
            }
        ],
        '25.216': [
            '25.216px',
            {
                lineHeight: '29.533px',
                letterSpacing: '-0.50432px'
            }
        ],
        '23.68': [
            '23.68px',
            {
                lineHeight: '28.416px',
                letterSpacing: '-0.4736px'
            }
        ],
        '22.144': [
            '22.144px',
            {
                lineHeight: '33.216px'
            }
        ],
        '19.2': [
            '19.2px',
            {
                lineHeight: '19.2px'
            }
        ],
        '16.5': [
            '16.5px',
            {
                lineHeight: 'normal'
            }
        ],
        '16.32': [
            '16.32px',
            {
                lineHeight: '16.32px'
            }
        ],
        '14.4': [
            '14.4px',
            {
                lineHeight: '21.6px'
            }
        ]
    },
    spacing: {
        '0': '1px',
        '1': '4px',
        '2': '19px',
        '3': '22px',
        '4': '25px',
        '5': '30px',
        '6': '32px',
        '7': '38px',
        '8': '43px',
        '9': '48px',
        '10': '51px',
        '11': '64px',
        '12': '77px',
        '13': '84px',
        '14': '146px',
        '15': '274px',
        '16': '323px'
    },
    borderRadius: {
        xs: '2px',
        lg: '12px',
        full: '300px'
    },
    boxShadow: {
        sm: 'rgb(128, 128, 128) 0px 0px 5px 0px',
        xs: 'rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px'
    },
    screens: {
        '240px': '240px',
        sm: '576px',
        md: '769px',
        lg: '1025px',
        xl: '1281px'
    },
    transitionDuration: {
        '75': '0.075s',
        '100': '0.1s',
        '140': '0.14s',
        '150': '0.15s',
        '170': '0.17s',
        '200': '0.2s',
        '250': '0.25s',
        '300': '0.3s',
        '400': '0.4s',
        '500': '0.5s',
        '600': '0.6s',
        '1000': '1s'
    },
    transitionTimingFunction: {
        default: 'ease',
        linear: 'linear',
        custom: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)'
    },
    container: {
        center: true,
        padding: '0px'
    },
    maxWidth: {
        container: '100%'
    }
},
  },
};
