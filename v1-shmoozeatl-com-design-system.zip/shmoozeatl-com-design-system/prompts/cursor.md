# Design brief
Page type: **landing**.
Material language: **flat**.
Voice: Tone: friendly · Headings: Title Case · CTA verbs: [object Object], [object Object], [object Object], [object Object], [object Object], [object Object].
## Tokens
```ts
export const tokens = {
  colors: ['#000000', '#333333', '#ffffff', '#e1ded4', '#bbbbbb', '#0099dd', '#efece6', '#a9a9a9', '#0d121c', '#cdd5df'],
  fonts: ['[object Object]', '[object Object]', '[object Object]'],
  radii: ['2', '12', '26', '50', '300'],
  shadows: ['rgba(0, 0, 0, 0) 0px 0px 0px 1px', 'rgb(0, 0, 0) 0px 0px 0px 0px', 'rgba(0, 0, 0, 0.05) 0px 2px 1px 0px, rgba(0, 0, 0, 0.25) 0px 0px 1px 0px'],
};
```
## Sections
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing — heading: "Businesses You Can Trust"
- testimonials
- footer