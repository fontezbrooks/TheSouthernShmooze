Create a React artifact that reproduces this brand's design language.
Page intent: landing.
Material language: flat.
Voice: Tone: friendly · Headings: Title Case · CTA verbs: [object Object], [object Object], [object Object], [object Object], [object Object], [object Object].
Colors to use: #000000, #333333, #ffffff, #e1ded4, #bbbbbb, #0099dd, #efece6, #a9a9a9, #0d121c, #cdd5df.
Fonts: [object Object], [object Object], [object Object].
Radius vocabulary: 2, 12, 26, 50, 300.
Sections:
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing-table — heading: "Atlanta’s Community for Finding Trusted Local Businesses"
- pricing — heading: "Businesses You Can Trust"
- testimonials
- footer
Use Tailwind via CDN, lucide-react for icons, and keep the material language consistent across sections. Do not add extra decorative elements outside this vocabulary.